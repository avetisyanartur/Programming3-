var express = require('express');
var app = express();
var server = require('http').Server(app);
var io = require('socket.io')(server);
var fs = require('fs');
var coords = [];

io.on('connection', function (socket) {
   
   socket.on("send message", function (static) {
      
       io.sockets.emit("display message", static);
       fs.appendFileSync("static.json", JSON.stringify(static)+"\n");
       


   })
});


app.use(express.static("."));
app.get('/', function (req, res) {
    res.redirect('index.html');
});
server.listen(3000);
