class Cat {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.energy = 8;
        this.directions = [];
        this.index = 2;
         this.gender = gender[getRandomInt(2)]
    }

    stanalNorKordinatner() {
        this.directions = [
            [this.x - 1, this.y - 1],
            [this.x, this.y - 1],
            [this.x + 1, this.y - 1],
            [this.x - 1, this.y],
            [this.x + 1, this.y],
            [this.x - 1, this.y + 1],
            [this.x, this.y + 1],
            [this.x + 1, this.y + 1]
        ];
    }
    yntrelVandak(ch) {
        this.stanalNorKordinatner();
        var found = [];
        for (var i in this.directions) {
            var x = this.directions[i][0];
            var y = this.directions[i][1];
            if (x >= 0 && x < matrix[0].length && y >= 0 && y < matrix.length) {

                if (matrix[y][x] == ch) {
                    found.push(this.directions[i]);
                }
            }
        }
        return found;
    }
    satkel() {
        if (this.energy < 0) {
            for (var c in cat) {
                if (cat[c].x == this.x && cat[c].y == this.y) {
                    matrix[this.y][this.x] = 0
                    cat.splice(c, 1);
                }
            }

        }

    }
    sharjvel() {
        this.stanalNorKordinatner();

        var vandak = random(this.yntrelVandak(0))
        if (vandak) {
            matrix[this.y][this.x] = 0
            this.x = vandak[0]; this.y = vandak[1];
            matrix[this.y][this.x] = 8

        }

    }
    bazmanal() {
        this.stanalNorKordinatner();
        var vandak = random(this.yntrelVandak(0));
        if (this.energy == 8 && vandak) {
            var norcat = new Cat(vandak[0], vandak[1]);
            cat.push(norcat);
        }


    }
    utel() {
        this.stanalNorKordinatner();
        var xotvandak = random(this.yntrelVandak(2))
        if (xotvandak) {
        	if (yntrelExanak == exanak[1]) {
            this.energy++;
            matrix[this.y][this.x] = 0
            for (var i in mouse) {
                if (mouse[i].x == this.x && mouse[i].y == this.y) {

                    mouse.splice(i,1)
                    break;
                   
                }
            }
           
            this.x = xotvandak[0]; this.y = xotvandak[1];
            matrix[this.y][this.x] = 2;
}
else{
	  this.energy+2;
            matrix[this.y][this.x] = 0
            for (var i in mouse) {
                if (mouse[i].x == this.x && mouse[i].y == this.y) {

                    mouse.splice(i,1)
                    break;
                   
                }
            }
           
            this.x = xotvandak[0]; this.y = xotvandak[1];
            matrix[this.y][this.x] = 2;

}
        }
        else {

            this.energy--;

        }

    }
}