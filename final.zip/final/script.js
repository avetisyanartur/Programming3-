var socket = io.connect();
if (yntrelExanak == exanak[0]) {
    var matrix = [
        [1, 1, 1, 0, 0, 1, 1, 1, 0, 8],
        [1, 0, 0, 0, 0, 1, 1, 1, 0, 0],
        [0, 1, 8, 0, 0, 1, 1, 1, 0, 0],
        [0, 0, 1, 1, 1, 1, 1, 1, 0, 0],
        [1, 1, 1, 0, 0, 1, 1, 1, 5, 2],
        [1, 1, 5, 0, 0, 1, 1, 1, 0, 0],
        [1, 1, 0, 1, 1, 1, 0, 1, 0, 0],
    ];
    console.log(exanak[0])
}
else if (yntrelExanak == exanak[1]) {
    var matrix = [
        [1, 1, 1, 0, 0, 1, 1, 1, 0, 0],
        [1, 0, 0, 0, 0, 1, 1, 1, 0, 0],
        [0, 1, 8, 0, 0, 1, 10, 1, 0, 0],
        [0, 0, 1, 10, 1, 1, 1, 1, 0, 0],
        [1, 1, 1, 2, 0, 1, 10, 1, 5, 0],
        [1, 1, 5, 0, 0, 1, 1, 1, 0, 0],
        [1, 1, 0, 1, 1, 1, 0, 1, 0, 8],

    ];
    console.log(exanak[1])

}
else if (yntrelExanak == exanak[2]) {
    var matrix = [
        [1, 1, 1, 0, 0, 1, 1, 1, 0, 8],
        [1, 0, 0, 0, 0, 1, 1, 1, 0, 0],
        [0, 1, 8, 0, 0, 1, 1, 1, 0, 0],
        [0, 0, 1, 1, 1, 1, 1, 1, 0, 0],
        [1, 1, 1, 0, 0, 1, 1, 1, 5, 2],
        [1, 1, 5, 0, 0, 1, 1, 1, 0, 0],
        [1, 1, 0, 1, 1, 1, 0, 1, 0, 0],
    ];
    console.log(exanak[2])

}
else if (yntrelExanak == exanak[3]) {
    var matrix = [
        [1, 1, 1, 0, 0, 1, 1, 1, 0, 8],
        [1, 0, 0, 0, 0, 1, 1, 1, 0, 0],
        [0, 1, 8, 0, 0, 1, 1, 1, 0, 0],
        [0, 0, 1, 1, 1, 1, 1, 1, 0, 0],
        [1, 1, 1, 0, 0, 1, 1, 1, 5, 2],
        [1, 1, 5, 0, 0, 1, 1, 1, 0, 0],
        [1, 1, 0, 1, 1, 1, 0, 1, 0, 0],

    ];
    console.log(exanak[3])

}

var input = document.getElementById('tatibtn');
var tiv = 10;
function tatifnc() {
    console.log('hi')
    if (tiv > 0) {


        tati.push(new Tati(getRandomInt(1), getRandomInt(1)));
        --tiv
        alert(tiv);
    }
    else {
        alert("error");
    }



}

var chess = [];
var dog = [];
var cat = [];
var mouse = [];
var tati = [];
var side = 100;
function setup() {
    for (var y = 0; y < matrix.length; ++y) {
        for (var x = 0; x < matrix[y].length; ++x) {

            if (matrix[y][x] == 1) {
                var gr = new Chess(x, y);
                chess.push(gr);
            }
            else if (matrix[y][x] == 2) {
                mouse.push(new Mouse(x, y));

            }
            else if (matrix[y][x] == 8) {
                cat.push(new Cat(x, y));

            }
            else if (matrix[y][x] == 5) {
                dog.push(new Dog(x, y));

            }

        }
    }

    frameRate(5);
    createCanvas(matrix[0].length * side, matrix.length * 150);

    background('#acacac');
}
var static;
function draw() {
    if(frameCount % 60 == 0){
        static = {
            "chees" : chess.length,
            "mouse" : mouse.length,
            "cat" : cat.length,
            "dog" : dog.length,
            "tati" : tati.length
        }
        socket.emit("send message", static);

    }
    for (var i in chess) {

    }
    for (var i in mouse) {
        mouse[i].sharjvel();
        mouse[i].utel();
        mouse[i].bazmanal();
        mouse[i].satkel();


    }
    for (var i in cat) {
        cat[i].sharjvel();
        cat[i].utel();
        cat[i].bazmanal();

        cat[i].satkel();
    }
    for (var i in tati) {
        tati[i].sharjvel();
        tati[i].utel();
    }
    for (var i in dog) {
        dog[i].sharjvel();
        dog[i].utel();
        dog[i].bazmanal();



    }
    for (var y = 0; y < matrix.length; y++) {
        for (var x = 0; x < matrix[y].length; x++) {
            if (matrix[y][x] == 1) {
                fill("yellow");

            }
            else if (matrix[y][x] == 0) {
                fill("#acacac");

            }
            else if (matrix[y][x] == 2) {
                fill("red");

            }
            else if (matrix[y][x] == 8) {
                fill("black");
            }
            else if (matrix[y][x] == 5) {
                fill("green");
            }
            else if (matrix[y][x] == 10) {
                fill("white");
            }
            else if (matrix[y][x] == 6) {
                fill("blue");
            }
            rect(x * side, y * side, 200, 200);

        }
    }
    fill('#acacac');
    // stroke('#acacac');
    strokeWeight(2);

    rect(15, 840, 250, 220);
    fill('black');

    textSize(32);
    text('tati' + ' ' + tati.length, 20, 900);
    text('chess' + ' ' + chess.length, 20, 930);
    text('mouse' + ' ' + mouse.length, 20, 960);
    text('cat' + ' ' + cat.length, 20, 990);
    text('dog' + ' ' + dog.length, 20, 1020);
    text(yntrelExanak,50,1050)
  
}